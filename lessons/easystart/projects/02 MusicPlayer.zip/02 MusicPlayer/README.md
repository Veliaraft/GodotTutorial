# Instructions

Make an addons folder in your godot project and add the aud_vis folder in it.
