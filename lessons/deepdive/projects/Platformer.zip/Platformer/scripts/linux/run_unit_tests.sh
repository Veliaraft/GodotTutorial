# Must be called from project root folder
godot -d -s --path $PWD addons/gut/gut_cmdln.gd -gdir=res://gut/unit -gmaximize -glog=2
